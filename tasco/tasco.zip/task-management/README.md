# Task Management

A Pen created on CodePen.io. Original URL: [https://codepen.io/alphardex/pen/xxGoKEO](https://codepen.io/alphardex/pen/xxGoKEO).

From shot: https://dribbble.com/shots/6816310--Exploration-Dashboard-for-Task-Management

Made with aqua.css: https://aquacss.netlify.com/