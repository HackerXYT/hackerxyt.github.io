# Imagica - AI prompt UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/onediv/pen/rNoqMvO](https://codepen.io/onediv/pen/rNoqMvO).

Pen inspired by ImagicaAI demo video :
https://dopniceu5am9m.cloudfront.net/static/imagica.ai/230925/Recepie_Music_.mp4