const form = document.getElementById("form");
const heading = document.getElementById("heading");
heading.onclick = (e) => {
  form.classList.toggle('open')
}