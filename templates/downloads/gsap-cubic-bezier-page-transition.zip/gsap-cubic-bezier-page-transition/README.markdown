# GSAP Cubic bezier page transition

A Pen created on CodePen.io. Original URL: [https://codepen.io/Polenji86/pen/KNabaJ](https://codepen.io/Polenji86/pen/KNabaJ).


